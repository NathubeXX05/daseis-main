#!/usr/bin/env python3
"""
Homonobus v2 : thème clair, sobre. Part des fichiers d'origine et écrit dans src/.
Principe : les composants sont écrits pour un fond sombre ("text-white" = texte principal,
"text-slate-400" = texte secondaire...). Le thème INVERSE ces échelles de couleur pour
obtenir une interface claire sans réécrire chaque classe.
Usage : python3 build_v2.py <dossier_origine> <dossier_projet>
"""
import colorsys, pathlib, re, shutil, sys

SRC = pathlib.Path(sys.argv[1])
ROOT = pathlib.Path(sys.argv[2])
OUT = ROOT / "src"
COMP = OUT / "components"
COMP.mkdir(parents=True, exist_ok=True)
HAND = {"HomeLanding.tsx", "AssetCard.tsx", "OndoTickerMarquee.tsx"}  # écrits à la main

# ------------------------------------------------------------------ thème
STEPS = [50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 950]
LIGHT = [97, 93, 86, 77, 67, 56, 46, 37, 28, 19, 11]
MIRROR = dict(zip(STEPS, reversed(STEPS)))


def hexc(h, l, s):
    r, g, b = colorsys.hls_to_rgb(h / 360, l / 100, s)
    return f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}"


def inv_scale(name, hue, sat):
    """Échelle inversée : name-50 est foncé, name-950 est clair."""
    rows = []
    for step in STEPS:
        l = LIGHT[STEPS.index(MIRROR[step])]
        rows.append(f"  --color-{name}-{step}: {hexc(hue, l, sat * (0.45 if l > 90 else 1))};")
    return "\n".join(rows)


scales = "\n".join(
    inv_scale(n, h, s) for n, h, s in [
        ("slate", 218, 0.18), ("zinc", 218, 0.18), ("gray", 218, 0.18), ("neutral", 218, 0.18),
        ("emerald", 155, 0.42), ("amber", 38, 0.85), ("rose", 352, 0.55),
        ("cyan", 218, 0.18), ("teal", 218, 0.18), ("blue", 218, 0.18), ("purple", 218, 0.18),
    ]
)

CSS = f"""@import "tailwindcss";

@theme {{
  --font-sans: 'IBM Plex Sans', system-ui, -apple-system, sans-serif;
  --font-serif: 'Source Serif 4', Georgia, 'Times New Roman', serif;
  --font-mono: 'IBM Plex Sans', system-ui, -apple-system, sans-serif;

  /* Surfaces */
  --color-canvas: #ffffff;
  --color-panel: #f5f6f8;
  --color-raised: #eceff3;
  --color-paper: #ffffff;

  /* Accent unique : bordeaux (boutons, focus) */
  --color-accent: #7b2332;
  --color-accent-hover: #651c29;
  --color-on-accent: #ffffff;

  /* "white" = couleur du texte principal dans ce thème (échelles inversées ci-dessous). */
  --color-white: #121b2b;

{scales}
}}

@layer base {{
  html {{ color-scheme: light; }}
  body {{
    font-family: var(--font-sans);
    color: var(--color-slate-200);
    background-color: var(--color-canvas);
    font-variant-numeric: tabular-nums;
    -webkit-font-smoothing: antialiased;
  }}
  h1, h2 {{ font-family: var(--font-serif); font-weight: 400; letter-spacing: -0.01em; }}
  :focus-visible {{ outline: 2px solid var(--color-accent); outline-offset: 2px; }}
  ::selection {{ background: rgba(123, 35, 50, 0.18); }}
}}

::-webkit-scrollbar {{ width: 8px; height: 8px; }}
::-webkit-scrollbar-track {{ background: var(--color-canvas); }}
::-webkit-scrollbar-thumb {{ background: #c9ced6; }}

@media print {{ :root {{ --color-white: #ffffff; }} }}
@media (prefers-reduced-motion: reduce) {{
  *, *::before, *::after {{ animation: none !important; transition: none !important; }}
}}
"""
(OUT / "index.css").write_text(CSS)

# ------------------------------------------------------- textes à corriger
COPY = [
    ("La preuve mathématique qu'investir selon la Doctrine Sociale de l'Église (DSE) rapporte <strong>davantage de richesse</strong> que les placements d'épargne traditionnels.",
     "Simulation illustrative, sur des hypothèses de rendement annuel constant. Non garantie : les performances passées ne préjugent pas des performances futures."),
    ("Vérité des Chiffres", "Simulation"),
    ("N°1 PERFORMANCE & ÉTHIQUE", "Hypothèse haute"),
    ("~11.4 % / an", "11,4 % / an (hypothèse)"),
    ("1. Zéro Scandales ni Amendes", "Moins d'exposition aux controverses"),
    ("Les entreprises sans scandales bioéthiques ou écologiques évitent les krachs boursiers et les amendes de milliards d'euros.",
     "Écarter les entreprises exposées à des controverses peut réduire certains risques, sans garantir une meilleure performance."),
    ("2. Leaders de l'Économie Réelle", "Entreprises de l'économie réelle"),
    ("Air Liquide, Schneider Electric ou L'Oréal possèdent des monopoles industriels indestructibles et augmentent leurs prix sans perdre de clients.",
     "Air Liquide, Schneider Electric ou L'Oréal occupent des positions de marché solides. Cela ne préjuge pas de leurs résultats futurs."),
    ("3. Dividendes Réinvestis", "Dividendes réinvestis"),
    ("Inclus des armes de guerre, du tabac et des forages polluants. Volatilité élevée lors des scandales extra-financiers.",
     "L'indice inclut des secteurs que le filtre DSE exclut (armement, tabac, énergies fossiles)."),
    ("Compte séquestre bancaire cantonné sous régulation ACPR / Banque de France.", "Mode démonstration : aucun fonds réel n'est débité."),
    ("Carnet d'ordres MIFID II / DSE", "Carnet d'ordres (démonstration)"),
    ("Exécution sur carnet d'ordres régulé via l'infrastructure Homonobus Brokerage. Conforme directive MIFID II & DSE.",
     "Mode démonstration : aucun ordre réel n'est transmis à un marché."),
    ("Règlement-livraison instantané sous mandat d'exclusion éthique DSE et conformité MIFID II.", "Mode démonstration : les exécutions sont simulées."),
    ("Actif homologué & ajouté", "Actif ajouté"),
    ("Certifications & Agréments Éthiques", "Labels et signatures"),
    ("Fonds Catholique Homologué CEF", "Fonds éthique"),
    ("Agrément Conférence des Évêques de France & USCCB", "Méthodologie inspirée de la doctrine sociale de l'Église"),
    ("Eligible PEA uniquement (0% d'impôt après 5 ans)", "Éligible PEA uniquement"),
    ("100% Conforme DSE & Éthique", "Classés selon le score DSE"),
    ("Homologué DSE", "Score DSE"),
    ("100% Garanti ✓", "Filtre appliqué"),
    ("Véhicule Chrétien Homologué de Remplacement :", "Alternative compatible DSE :"),
    ("Certificat de Conformité Pastorale & Éthique", "Rapport d'analyse extra-financière"),
    ("HOMONOBUS • OBSERVATOIRE DE LA FINANCE CATHOLIQUE", "Homonobus"),
    ("Attestation Pastorale & Rapport Officiel DSE", "Rapport d'analyse DSE"),
    ("Comité Pastoral Homonobus", "Analyse automatisée Homonobus"),
    ("Tiers de confiance pour les diocèses & particuliers", "Indicatif : n'émane d'aucune autorité ecclésiale"),
    ("★ AUDITÉ & HOMOLOGUÉ ★", "ANALYSE AUTOMATISÉE"),
    ("DSE CONFORME", "Score indicatif"),
    ("Document généré pour valoir justification d'alignement éthique auprès de conseils d'administration, trésoriers et banquiers privés.",
     "Document indicatif généré automatiquement. Il ne constitue ni une attestation officielle de l'Église ni un conseil en investissement."),
    ("'✓ Homologué'", "'Compatible'"),
    ("Audits de portefeuille certifiés DSE", "Analyses de portefeuille selon la DSE"),
    ("Conformité directives diocésaines & CEF", "Critères inspirés des orientations de la CEF"),
    ("Protection pastorale et secret professionnel.", "Vos données restent confidentielles."),
    ("✦ ", ""), (" ✦", ""), ("🔥 ", ""), ("📈 ", ""), ("✝️ ", ""), ("⚠️ ", ""), ("⚠ ", ""), (" →", ""),
]
ACCENT = "bg-accent hover:bg-accent-hover text-on-accent"
CTA = [
    ("bg-emerald-500 hover:bg-emerald-400 text-slate-950", ACCENT),
    ("bg-white hover:bg-neutral-200 text-slate-950", ACCENT),
    ("bg-amber-500 text-zinc-950", "bg-accent text-on-accent"),
    ("focus:border-emerald-500", "focus:border-accent"),
    ("hover:border-emerald-500/40", "hover:border-white/30"),
    ("hover:border-emerald-500/30", "hover:border-white/30"),
]
STRIP = [r"uppercase", r"tracking-(?:wide|wider|widest)", r"tracking-\[[^\]]*\]",
         r"animate-(?:ping|pulse)", r"shadow-(?:sm|md|lg|xl|2xl)", r"shadow-\[[^\]]*\]",
         r"active:scale-\d+", r"backdrop-blur-(?:sm|md)"]
CHART = [("#059669", "#1f6b4f"), ("#10b981", "#1f6b4f"), ("#047857", "#17563f"), ("#e11d48", "#a4332f"),
         ("#222836", "#d9dde3"), ("fill: '#cbd5e1'", "fill: '#121b2b'"), ("stroke: '#cbd5e1'", "stroke: '#9aa3b2'"),
         ('fill="#334155"', 'fill="#9aa3b2"')]

FLIP_STEP = {50: 950, 100: 900, 200: 800, 300: 700, 400: 600, 500: 500, 600: 400, 700: 300, 800: 200, 900: 100, 950: 50}


def flip(text):
    """Pour les blocs qui étaient déjà écrits en clair : ils doivent rester clairs après inversion."""
    t = re.sub(r"\b(slate|zinc|emerald|amber|rose)-(\d+)\b", lambda m: f"{m.group(1)}-{FLIP_STEP.get(int(m.group(2)), m.group(2))}", text)
    t = re.sub(r"(?<![\w-])bg-white\b(?!/)", "bg-paper", t)
    t = re.sub(r"(?<![\w-])text-white\b(?!/)", "text-paper", t)
    return t


def lum(h):
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255


def hexmap(m):
    v = lum(m.group(1))
    return "canvas" if v < 0.055 else "panel" if v < 0.09 else "raised" if v < 0.2 else m.group(0)


FULLY_LIGHT = {"InteractiveSparkline.tsx", "DividendHistoryChart.tsx"}
GRID = "minmax(0,2.4fr)_1.1fr_0.7fr_0.8fr_1.1fr_12rem"
missed_all = []

for f in sorted(SRC.glob("*.tsx")):
    if f.name in HAND or f.name == "main.tsx":
        continue
    s = f.read_text()
    for a, b in COPY:
        if a in s:
            s = s.replace(a, b)
        elif len(a) > 14:
            missed_all.append((f.name, a[:45]))
    for a, b in CTA:
        s = s.replace(a, b)
    s = re.sub(r"\[#([0-9a-fA-F]{6})\]", hexmap, s)
    for pat in STRIP:
        s = re.sub(rf"(?<=[\s\"'`]){pat}(?=[\s\"'`])", "", s)
    s = re.sub(r"\bfont-black\b", "font-semibold", s)
    s = re.sub(r"text-\[(?:9|10|11)px\]", "text-xs", s)
    for a, b in CHART:
        s = s.replace(a, b)
    s = re.sub(r"\n\s*whileHover=\{\{[^}]*\{[^}]*\}\s*\}\}", "", s)
    if f.name in FULLY_LIGHT:
        s = flip(s)
    if f.name == "CertificateModal.tsx":
        a = s.index("<div ref={printRef}")
        b = s.index("{/* Footer note */}")
        s = s[:a] + flip(s[a:b]) + s[b:]
    if f.name == "App.tsx":
        ul = '<ul className="space-y-3 relative">'
        i = s.index(ul)
        j = s.index("</ul>", i)
        header = ('<><div className="hidden md:grid md:grid-cols-[' + GRID + '] gap-4 px-1 py-2 border-b border-white '
                  'text-xs font-medium text-slate-400"><span>Actif</span><span>Cours</span><span>Score DSE</span>'
                  '<span>Dividende</span><span>Verdict</span><span /></div><ul className="relative">')
        s = s[:i] + header + s[i + len(ul):j] + "</ul></>" + s[j + 5:]
    s = re.sub(r'className="([^"]*)"', lambda m: 'className="' + re.sub(r"\s{2,}", " ", m.group(1)).strip() + '"', s)
    (COMP / f.name).write_text(s)

# AssetCard : même grille que l'en-tête
p = COMP / "AssetCard.tsx"
if p.exists():
    p.write_text(p.read_text().replace("_auto]", "_12rem]"))

# App.tsx et main.tsx vivent dans src/
(OUT / "App.tsx").write_text((COMP / "App.tsx").read_text())
(COMP / "App.tsx").unlink()
shutil.copy(SRC / "main.tsx", OUT / "main.tsx")
for name in ("actions.ts", "isin_database.ts"):
    shutil.copy(SRC / name, OUT / name)  # inchangés

# index.html
h = (SRC / "index.html").read_text()
h = re.sub(r'<link href="https://fonts.googleapis.com/css2[^>]*>',
           '<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600&family=Source+Serif+4:opsz,wght@8..60,400;8..60,600&display=swap" rel="stylesheet">', h)
h = h.replace("maximum-scale=1.0, user-scalable=no, ", "")  # n'empêche plus le zoom (accessibilité)
h = h.replace('theme-color" content="#08090d"', 'theme-color" content="#ffffff"')
h = h.replace("black-translucent", "default")
h = re.sub(r'<body class="[^"]*">', '<body class="bg-canvas text-slate-200 min-h-screen selection:bg-accent/20">', h)
(ROOT / "index.html").write_text(h)

# bandeau de cours (version calme) repris de la v1
t = pathlib.Path("/mnt/user-data/outputs/homonobus-redesign/src/components/OndoTickerMarquee.tsx")
if t.exists():
    shutil.copy(t, COMP / "OndoTickerMarquee.tsx")

for n, a in missed_all:
    print(f"[non trouvé] {n}: {a}")
print("OK")
