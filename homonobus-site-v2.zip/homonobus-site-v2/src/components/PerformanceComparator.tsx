import React, { useState, useMemo } from 'react';
import { TrendingUp, ShieldAlert, Award, ArrowRight, Zap, CheckCircle2, DollarSign, BarChart3 } from 'lucide-react';
import clsx from 'clsx';

interface PerformanceComparatorProps {
  onExplorePortfolio?: () => void;
}

export function PerformanceComparator({ onExplorePortfolio }: PerformanceComparatorProps) {
  const [initialCapital, setInitialCapital] = useState<number>(10000);
  const [years, setYears] = useState<number>(5);

  // Taux de rendement annualisés moyens (CAGR historique dividendes réinvestis)
  const RATES = {
    livretA: 0.030, // 3.0% net
    cac40: 0.078,   // 7.8% brut
    dseEthics: 0.114 // 11.4% (Compounders éthiques de haute qualité : Schneider, Air Liquide, etc.)
  };

  const calculateFinalAmount = (capital: number, rate: number, horizon: number) => {
    return capital * Math.pow(1 + rate, horizon);
  };

  const results = useMemo(() => {
    const livretAFinal = calculateFinalAmount(initialCapital, RATES.livretA, years);
    const cac40Final = calculateFinalAmount(initialCapital, RATES.cac40, years);
    const dseFinal = calculateFinalAmount(initialCapital, RATES.dseEthics, years);

    const dseGain = dseFinal - initialCapital;
    const livretAGain = livretAFinal - initialCapital;
    const cac40Gain = cac40Final - initialCapital;

    const outperformanceVsLivretA = dseFinal - livretAFinal;
    const outperformanceVsCac40 = dseFinal - cac40Final;

    return {
      livretAFinal,
      cac40Final,
      dseFinal,
      dseGain,
      livretAGain,
      cac40Gain,
      outperformanceVsLivretA,
      outperformanceVsCac40
    };
  }, [initialCapital, years]);

  const maxVal = results.dseFinal;

  return (
    <div className="bg-panel border border-white/10 p-5 sm:p-7 rounded-none">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-5 border-b border-white/10">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-mono text-xs font-bold">
              Simulation
            </span>
            <span className="text-slate-500 text-xs">·</span>
            <span className="text-slate-400 text-xs font-mono">Performance & Intérêts Composés</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-semibold tracking-tight text-white flex items-center gap-2">
            <BarChart3 className="w-6 h-6 text-emerald-400" />
            Portefeuille DSE vs Livret A vs CAC 40
          </h3>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl font-sans">
            Simulation illustrative, sur des hypothèses de rendement annuel constant. Non garantie : les performances passées ne préjugent pas des performances futures.
          </p>
        </div>

        {/* Inputs Panel */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="bg-panel border border-white/10 p-2.5 rounded-none">
            <span className="text-xs font-mono text-slate-400 block mb-1">Capital Initial :</span>
            <div className="flex items-center gap-1">
              <span className="text-emerald-400 font-mono font-bold">€</span>
              <input
                type="number"
                value={initialCapital}
                onChange={(e) => setInitialCapital(Math.max(1000, Number(e.target.value) || 0))}
                step={1000}
                className="w-24 bg-transparent text-white font-mono font-bold text-sm focus:outline-none"
              />
            </div>
          </div>

          <div className="bg-panel border border-white/10 p-2.5 rounded-none">
            <span className="text-xs font-mono text-slate-400 block mb-1">Horizon de placement :</span>
            <div className="flex items-center gap-1 font-mono text-xs">
              {[1, 3, 5, 10].map(h => (
                <button
                  key={h}
                  onClick={() => setYears(h)}
                  className={clsx(
                    'px-2 py-0.5 border cursor-pointer transition-all rounded-none',
                    years === h
                      ? 'bg-emerald-500 text-slate-950 font-bold border-emerald-400'
                      : 'border-white/10 text-slate-400 hover:text-white'
                  )}
                >
                  {h} an{h > 1 ? 's' : ''}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Comparison Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
        {/* 1. Livret A */}
        <div className="bg-panel border border-white/10 p-4 rounded-none relative">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono font-bold text-slate-400">
              1. Livret A Bancaire
            </span>
            <span className="text-xs font-mono px-1.5 py-0.2 bg-slate-800 text-slate-400 border border-slate-700">
              3.0 % / an
            </span>
          </div>

          <div className="text-2xl font-semibold font-mono text-slate-300">
            {results.livretAFinal.toLocaleString('fr-FR', { minimumFractionDigits: 0, maximumFractionDigits: 0 })} €
          </div>
          <div className="text-xs font-mono text-slate-400 mt-0.5">
            Gain net : +{results.livretAGain.toLocaleString('fr-FR', { minimumFractionDigits: 0, maximumFractionDigits: 0 })} €
          </div>

          <div className="w-full bg-white/5 h-2 mt-3 rounded-none overflow-hidden">
            <div
              className="bg-slate-500 h-full transition-all duration-500"
              style={{ width: `${(results.livretAFinal / maxVal) * 100}%` }}
            />
          </div>

          <p className="text-xs text-slate-500 mt-3 font-sans leading-snug">
            <strong>Plafonné à 22 950 €</strong>. Avec l'inflation réelle (~2.5% à 3.5%), votre pouvoir d'achat stagne ou diminue.
          </p>
        </div>

        {/* 2. CAC 40 Classique */}
        <div className="bg-panel border border-white/10 p-4 rounded-none relative">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono font-bold text-slate-300">
              2. CAC 40 Standard
            </span>
            <span className="text-xs font-mono px-1.5 py-0.2 bg-amber-500/10 text-amber-400 border border-amber-500/20">
              ~7.8 % / an
            </span>
          </div>

          <div className="text-2xl font-semibold font-mono text-amber-300">
            {results.cac40Final.toLocaleString('fr-FR', { minimumFractionDigits: 0, maximumFractionDigits: 0 })} €
          </div>
          <div className="text-xs font-mono text-amber-500/80 mt-0.5">
            Gain net : +{results.cac40Gain.toLocaleString('fr-FR', { minimumFractionDigits: 0, maximumFractionDigits: 0 })} €
          </div>

          <div className="w-full bg-white/5 h-2 mt-3 rounded-none overflow-hidden">
            <div
              className="bg-amber-400 h-full transition-all duration-500"
              style={{ width: `${(results.cac40Final / maxVal) * 100}%` }}
            />
          </div>

          <p className="text-xs text-slate-400 mt-3 font-sans leading-snug">
            L'indice inclut des secteurs que le filtre DSE exclut (armement, tabac, énergies fossiles).
          </p>
        </div>

        {/* 3. Portefeuille Homonobus DSE */}
        <div className="bg-gradient-to-b from-raised to-panel border-2 border-emerald-500 p-4 rounded-none relative">
          <div className="absolute -top-3 right-3 bg-emerald-500 text-slate-950 font-mono font-semibold text-xs px-2 py-0.5 shadow">
            Hypothèse haute
          </div>

          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono font-bold text-emerald-400">
              3. Portefeuille DSE Catholique
            </span>
            <span className="text-xs font-mono px-1.5 py-0.2 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold">
              11,4 % / an (hypothèse)
            </span>
          </div>

          <div className="text-3xl font-semibold font-mono text-emerald-300">
            {results.dseFinal.toLocaleString('fr-FR', { minimumFractionDigits: 0, maximumFractionDigits: 0 })} €
          </div>
          <div className="text-xs font-mono text-emerald-400 font-semibold mt-0.5">
            Gain net : +{results.dseGain.toLocaleString('fr-FR', { minimumFractionDigits: 0, maximumFractionDigits: 0 })} €
          </div>

          <div className="w-full bg-white/10 h-2 mt-3 rounded-none overflow-hidden">
            <div
              className="bg-emerald-400 h-full transition-all duration-500"
              style={{ width: '100%' }}
            />
          </div>

          <div className="mt-3 pt-2 border-t border-emerald-500/30 flex items-center justify-between text-xs font-mono">
            <span className="text-emerald-200">Surplus vs Livret A :</span>
            <span className="text-emerald-400 font-semibold">
              +{results.outperformanceVsLivretA.toLocaleString('fr-FR', { minimumFractionDigits: 0, maximumFractionDigits: 0 })} €
            </span>
          </div>
        </div>
      </div>

      {/* Why it outperforms box */}
      <div className="mt-6 p-4 bg-panel border border-white/10 grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-sans">
        <div className="flex items-start gap-2.5">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold text-white block mb-0.5">Moins d'exposition aux controverses</span>
            <span className="text-slate-400 leading-relaxed">
              Écarter les entreprises exposées à des controverses peut réduire certains risques, sans garantir une meilleure performance.
            </span>
          </div>
        </div>

        <div className="flex items-start gap-2.5">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold text-white block mb-0.5">Entreprises de l'économie réelle</span>
            <span className="text-slate-400 leading-relaxed">
              Air Liquide, Schneider Electric ou L'Oréal occupent des positions de marché solides. Cela ne préjuge pas de leurs résultats futurs.
            </span>
          </div>
        </div>

        <div className="flex items-start gap-2.5">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold text-white block mb-0.5">Dividendes réinvestis</span>
            <span className="text-slate-400 leading-relaxed">
              Les dividendes trimestriels et annuels sont réinjectés automatiquement pour démultiplier les intérêts composés d'année en année.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
